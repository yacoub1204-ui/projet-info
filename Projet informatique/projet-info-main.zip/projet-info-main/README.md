print("classes+attributs")




approvisionnement toles
	si premier approvisionnement chez fournisseur 1, alors tous les autres chez fournisseurs 1

	idem si c la fonderie interne qui approvisionne a la premiere commande




fonderie interne
	fusion d'une partie des stocks dispo/ déchets ( donc pas de cout d'acquisition)
	+ achat des matériaux purs(masse volumique, cout et poid connu)

	toutes les toles produites viennent de la meme tournee de production dans la fonderie
	
	cout processus fabrication
	definir qté produire pour COUT MINIMAL!!!!!!!!!!!




	retour prof pre rapport
partie 3 manque d'info (qlq classe)
manque classes solution			c les classes de stockage de solution et classe d'ecriture



fonderie: utiliser methode differente pour fonderie 

